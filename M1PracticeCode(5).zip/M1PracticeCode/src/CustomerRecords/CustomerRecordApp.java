package CustomerRecords;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class CustomerRecordApp {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Address a1 = new Address("12-A", "Hyderabad", "Maharashtra");
		Address a2 = new Address("12-B", "Delhi", "Karnataka");
		Address a3 = new Address("12-C", "Bengaluru", "Andhra-Pradesh");
		Address a4 = new Address("12-D", "Hyderabad", "Karnataka");
		Address a5 = new Address("12-E", "kolhapur", "Tamilnadu");
		Address a6 = new Address("12-F", "Hyderabad", "Maharashtra");
		Address a7 = new Address("12-G", "Delhi", "Karnataka");
		Address a8 = new Address("12-H", "Delhi", "Maharashtra");
		Address a9 = new Address("12-I", "Bengaluru", "Karnataka");
		Address a10 = new Address("12-J", "Hyderabad", "Andhra-Pradesh");

		Customer c1 = new Customer("Vishal", "vishal@gmail.com", a1, 11100, "online", "delivered");
		Customer c2 = new Customer("Pratik", "pratik@gmail.com", a2, 150, "cash", "dispatched");
		Customer c3 = new Customer("Omkar", "omkar@gmail.com", a3, 200, "online", "pending");
		Customer c4 = new Customer("Digvijay", "digvijay@gmail.com", a4, 160, "online", "pending");
		Customer c5 = new Customer("Rohan", "rohan@gmail.com", a5, 13200, "cash", "dispatched");
		Customer c6 = new Customer("Yogesh", "yogesh@gmail.com", a6, 150, "online", "delivered");
		Customer c7 = new Customer("Mahesh", "mahesh@gmail.com", a7, 160, "cash", "pending");
		Customer c8 = new Customer("Yashraj", "yashraj@gmail.com", a8, 200, "cash", "dispatched");
		Customer c9 = new Customer("Shubham", "shubham@gmail.com", a9, 11100, "online", "cancelled");
		Customer c10 = new Customer("Hrushikesh", "hrushikesh@gmail.com", a10, 11150, "cash", "delivered");
		
		ArrayList<Customer> allCustomers=new ArrayList<>();

		allCustomers.add(c1);
		allCustomers.add(c2);
		allCustomers.add(c3);
		allCustomers.add(c4);
		allCustomers.add(c5);
		allCustomers.add(c6);
		allCustomers.add(c7);
		allCustomers.add(c8);
		allCustomers.add(c9);
		allCustomers.add(c10);
		
		Scanner sc=new Scanner(System.in);
		System.out.println("1.Print All Customers");
		System.out.println("2.Print all Customer From Delhi");
		System.out.println("3.filter customers where order value >=1000"
				+ " and status set as delivered and city name hyderabad");
		System.out.println("4.Customer with maximum order value");
		
		System.out.print("Enter your Input: ");
		switch(sc.nextInt()) {
		case 1:
			System.out.println("\n------------------------------------------Customers List-------------------------------------");
			printAllCustomers(allCustomers);
			break;
			
		case 2:
			List<Customer> customersFromDelhi=customersFromDelhi(allCustomers);
			System.out.println("\n------------------------------------------Customers List From Delhi-------------------------------------");
			for(Customer c:customersFromDelhi) {
				System.out.println(c);
			}
			break;
			
		case 3:
			List<Customer> filteredCustomers=orderValueGreaterthan1000(allCustomers);
			System.out.println("\n------------------------------------------Customers List where order value >=1000 and status set as delivered -------------------------------------");
			for(Customer c:filteredCustomers) {
				System.out.println(c);
			}
			break;
			
		case 4:
			System.out.println("\n------------------------------------------Customer With Maximum Order Value-------------------------------------");
			List<Customer> customerWithMaximumOrderValue=customerWithMaximumOrderValue(allCustomers);
			System.out.println(customerWithMaximumOrderValue.get(customerWithMaximumOrderValue.size()-1));
			break;
		
			default:
				System.out.println("Invalid Input");
		}

	}//end main


	private static void printAllCustomers(ArrayList<Customer> customers) {
		customers.stream().forEach(x->{
			System.out.println(x);
		});
	}
	
	private static List<Customer> customersFromDelhi(ArrayList<Customer> allCustomers) {
		return allCustomers.stream()
				.filter(x->x.getAddress().cityName.equals("Delhi"))
				.collect(Collectors.toList());
	}
	
	private static List<Customer> orderValueGreaterthan1000(ArrayList<Customer> allCustomers) {
		return allCustomers.stream()
				.filter(x-> x.getAddress().cityName.equals("Hyderabad") && x.getOrderValue()>=1000)
				.map(x->{
					x.setStatus("Delivered");
					return x;
				})
				.collect(Collectors.toList());
	}
	
	private static List<Customer> customerWithMaximumOrderValue(ArrayList<Customer> allCustomers) {
		return allCustomers.stream()
				.sorted(Comparator.comparing(Customer::getOrderValue))
				.collect(Collectors.toList());
	}
}
