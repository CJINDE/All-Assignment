package ExceptionHandlingProblem;

public class InvalidUserNameException extends Exception{

	public InvalidUserNameException (String m) {
		super (m);
	}
}
