package foodapp.reviews.treemap.exception;

public class UserNameMisssingException extends Exception{

	public UserNameMisssingException (String message)

	{

		super(message);

	}

 
}
