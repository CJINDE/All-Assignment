package p2;



	import java.util.stream.Stream;

	public class ForEachDemo {

		public static void main(String[] args) {
			
			Stream.of("Sun","Mon","Tues").forEach((x)->
			{
				String t=x+"day";
				System.out.println(t);
			});
			
			
			//===========
			
			
		}
	
}
