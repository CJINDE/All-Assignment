package org.cg.student.main;


import org.cg.student.*;
import org.cg.student.entity.Student;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class MainApp {

	public static void main(String[] args) {
		ApplicationContext spring = new ClassPathXmlApplicationContext("Spring.xml");
	
		Student s = spring.getBean("student",Student.class);
		System.out.println(s);
		System.out.println(s.getProject());
		
		
		
	}
}
