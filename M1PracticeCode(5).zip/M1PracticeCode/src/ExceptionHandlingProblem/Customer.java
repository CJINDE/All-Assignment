package ExceptionHandlingProblem;

public class Customer {

	private String username;
	private double balance;

    public Customer(String username, double balance) throws InsufficientFundException,InvalidUserNameException {
    	if (username == null || username.length() < 3) {
            throw new InvalidUserNameException("Invalid username: Username must be at least 3 characters long.");
        }

 

        if (balance < 0) {
            throw new InsufficientFundException("Invalid balance amount: Balance cannot be negative.");
        }

        this.username = username;
        this.balance = balance;
    }

 

	public String getUsername() {
		return username;
	}

 

	public void setUsername(String username) {
		this.username = username;
	}

 

	public double getBalance() {
		return balance;
	}

 

	public void setBalance(double balance) {
		this.balance = balance;
	}

}

 

class BillPaymentService
{
	public boolean payBill(Customer customer,double billAmount)throws InsufficientFundException
	{
		if (customer.getBalance()<billAmount) {
			throw new InsufficientFundException("Insufficient Funds for Bill Payment");
		} else {
			return true;
		}
	}
}

 

 

 class ExceptionHandlingPracticeTest {

 

	public static void main(String[] args) throws InvalidUserNameException {

		 try {
	            Customer customer1 = new Customer("Alice", 300.0);
	            BillPaymentService bill = new BillPaymentService();

 

	            double billAmount = 600.0;
	            boolean paymentResult = bill.payBill(customer1, billAmount);

 

	            if (paymentResult) {
	                System.out.println("Payment successful.");
	            } else {
	                System.out.println("Payment failed.");
	            }
	        } catch (InsufficientFundException e) {
	            System.err.println("Exception: " + e.getMessage());
	        }
	}

}
