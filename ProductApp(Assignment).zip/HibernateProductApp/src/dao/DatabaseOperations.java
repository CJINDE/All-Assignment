package dao;

import org.hibernate.Session;
import org.hibernate.Transaction;
import models.Product;



public class DatabaseOperations {

	public static Session hibernateSession ;
	
	public DatabaseOperations() {
		hibernateSession = MyHibernateConfiguration.hibernateSession;
	}
	
	
	public Product getProductyByCost(int  cost)
	{
		Product savedEmp = (Product) hibernateSession.get(Product.class, cost);
		return savedEmp;
	}	
	public void saveProduct(Product e)
	{
		if(e != null)
		{
			Transaction t = hibernateSession.beginTransaction();
			hibernateSession.save(e);
			t.commit();
		}
	}
}
