package StartswithQue;

	import java.util.ArrayList;
	import java.util.Comparator;
	import java.util.List;
	import java.util.function.Consumer;
	import java.util.function.Predicate;

	 
	public class StartsWithQ {
		public static void main(String[] args) {
	System.out.println("\nStarts With 'S'\n");
			String s = "S";
			Predicate<String> pred = (str) -> {
				if (str.startsWith(s)){
					return true;
				}
				return false;
			};

			String arr1[] = {"Chetan","Pratyush","Sachine","Kaka","Shekhar","Pranay",};
			for (String t : arr1) {
				if (pred.test(t)) {
					System.out.println(t);
				}
			}


		}
	}

