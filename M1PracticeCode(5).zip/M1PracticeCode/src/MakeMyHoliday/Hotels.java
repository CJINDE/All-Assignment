package MakeMyHoliday;

public class Hotels {

	String hotelName;
	String cityname;
	float userRatings;
	public Hotels() {
		super();
	}
	public Hotels(String hotelName, String cityname, float userRatings) {
		super();
		this.hotelName = hotelName;
		this.cityname = cityname;
		this.userRatings = userRatings;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getCityname() {
		return cityname;
	}
	public void setCityname(String cityname) {
		this.cityname = cityname;
	}
	public float getUserRatings() {
		return userRatings;
	}
	public void setUserRatings(float userRatings) {
		this.userRatings = userRatings;
	}
	@Override
	public String toString() {
		return "Customers [hotelName=" + hotelName + ", cityname=" + cityname + ", userRatings=" + userRatings + "]";
	}
}
