package p1;



	public class Employee {
		
	   private String name;
	   private char gender;
	   private double yearsOfExp;
	   private String designation;
	   private double basicSalary;
	   private String status;

	   // Constructor
	   public Employee(String name, char gender) {
	       this.name = name;
	       this.gender = gender;
	       this.yearsOfExp = 0.0; // Default years of experience for fresher
	       this.designation = "ASE"; // Default designation for fresher
	       this.basicSalary = 10000.0; // Default basic salary for fresher
	       this.status = "Active"; // Default status for all employees
	   }

	   // Constructor for experienced employees
	   public Employee(String name, char gender, double yearsOfExp) {
	       this(name, gender);
	       this.yearsOfExp = yearsOfExp;
	       
	       // Set designation and basic salary based on years of experience
	       if (yearsOfExp >= 3) {
	           this.designation = "ITA";
	           this.basicSalary = 15000.0;
	       }
	   }

	   // Method to promote employee
	   public double promoteEmp() {

	       if (designation.equals("ASE")) {
	           designation = "ITA";
	           basicSalary *= 1.05; // Increment salary by 5%
	       } else if (designation.equals("ITA")) {
	           designation = "AST";
	           basicSalary *= 1.08; // Increment salary by 8%
	       } else if (designation.equals("AST")) {
	           designation = "ASC";
	           basicSalary *= 1.10; // Increment salary by 10%
	       }
	       return basicSalary;
	   }
	   // Method to apply for LWP
	   public void applyForLWP() {
	       status = "InActive";
	       basicSalary = 0.0;
	   }

	   // Getter methods for various attributes (name, gender, yearsOfExp, designation, basicSalary, status)
	   public String getName() {
	       return name;
	   }
	   public char getGender() {
	       return gender;
	   }
	   public double getYearsOfExp() {
	       return yearsOfExp;
	   }

	   public String getDesignation() {
	       return designation;
	   }

	   public double getBasicSalary() {
	       return basicSalary;
	   }
	   public String getStatus() {
	       return status;
	   }

	   // Main method for testing
	   public static void main(String[] args) {
	       // Create an employee object
	       Employee emp1 = new Employee("John Doe", 'M');
	       System.out.println("Employee 1:");
	       System.out.println("Name: " + emp1.getName());
	       System.out.println("Gender: " + emp1.getGender());
	       System.out.println("Years of Experience: " + emp1.getYearsOfExp());
	       System.out.println("Designation: " + emp1.getDesignation());
	       System.out.println("Basic Salary: " + emp1.getBasicSalary());
	       System.out.println("Status: " + emp1.getStatus());

	       // Promote the employee
	       emp1.promoteEmp();
	       System.out.println("After Promotion:");
	       System.out.println("Designation: " + emp1.getDesignation());
	       System.out.println("Basic Salary: " + emp1.getBasicSalary());

	       // Apply for LWP
	       emp1.applyForLWP();
	       System.out.println("After Applying for LWP:");
	       System.out.println("Status: " + emp1.getStatus());
	       System.out.println("Basic Salary: " + emp1.getBasicSalary());

	       // Create another employee object with experience
	       Employee emp2 = new Employee("Jane Smith", 'F', 4.5);
	       System.out.println("\nEmployee 2:");
	       System.out.println("Name: " + emp2.getName());
	       System.out.println("Gender: " + emp2.getGender());
	       System.out.println("Years of Experience: " + emp2.getYearsOfExp());
	       System.out.println("Designation: " + emp2.getDesignation());
	       System.out.println("Basic Salary: " + emp2.getBasicSalary());
	       System.out.println("Status: " + emp2.getStatus());
	   }

}
