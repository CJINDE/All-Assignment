package org.cg.student.entity;

import java.util.Objects;
import java.util.List;
import java.util.Objects;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
public class Student {
	@Value("101")
	private long studId;
	@Value("${name}")
	private String studname;
	@Value("#{1+5}")
	private int studRN;
	
	@Autowired
	private Project project;
	
	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(long studId, String studname, int studRN) {
		super();
		this.studId = studId;
		this.studname = studname;
		this.studRN = studRN;
	}




	public long getStudId() {
		return studId;
	}

	public void setStudId(long studId) {
		this.studId = studId;
	}

	public String getStudname() {
		return studname;
	}

	public void setStudname(String studname) {
		this.studname = studname;
	}

	public int getStudRN() {
		return studRN;
	}

	public void setStudRN(int studRN) {
		this.studRN = studRN;
	}
	


	
	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studname=" + studname + ", studRN=" + studRN + ", project=" + project
				+ "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(studId, studRN, studname);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return studId == other.studId && studRN == other.studRN && Objects.equals(studname, other.studname);
	}
	
}
