package p2;



	import java.util.function.Consumer;

	public class StreamOfStreamDemo {
		public static void main(String[] args) {
			
			Consumer<String> con=new Consumer<String>() {
				
				public void accept(String t) {
					String x=t+"day";
					System.out.println(x);
				}
			};
			
		String i[]= {"Sun","Mon","Tues"};
			for(String string:i) {
				
			};
			
		}
	

}
