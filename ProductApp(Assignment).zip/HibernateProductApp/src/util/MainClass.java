package util;

import java.time.LocalDate;
import dao.DatabaseOperations;
import models.Certification;
import models.Product;
import models.Vendor;

public class MainClass {

	DatabaseOperations dbOps;

	public MainClass() {
		dbOps = new DatabaseOperations();
	}
	
	public static void main(String[] args) {
		MainClass app = new MainClass();
		app.createProduct();
		app.getProduct();
	}
	
	public void getProduct()
	{
		int searchCost = 10;
		displayProduct(dbOps.getProductyByCost(searchCost));
	}
	
	public void displayProduct(Product e)
	{
		System.out.println(e);
	}
	
	public  void createProduct()
	{
		String strDom = "12-2-2020";
		String strDoe = "28-11-2021";
		
		LocalDate dom = DateConvertor.getDateFromString(strDom);
		LocalDate doe = DateConvertor.getDateFromString(strDoe);
		
		Product e1 = new Product(34, "maggie", 10, dom, doe, "snacks");
		Certification c1 = new Certification("Best IT Product", 1000);
		e1.setCr(c1);
		Vendor v1 = new Vendor(1, "CG", "Banglore");
		e1.setVr(v1);
		
		
		Product e2 = new Product(35, "Pasta", 60, dom, doe, "snacks");
		Certification c2 = new Certification("Best Mech Product", 1500);
		e2.setCr(c2);
		Vendor v2 = new Vendor(2,"Cooper","Satara");
		e2.setVr(v2);
		
		
		dbOps.saveProduct(e1);
		dbOps.saveProduct(e2);
	}
}
