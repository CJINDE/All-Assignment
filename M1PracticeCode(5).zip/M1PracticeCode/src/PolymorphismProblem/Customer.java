package PolymorphismProblem;

abstract class Customer {

	
	    public String username;
	    public int billAmount;

	 

	    public abstract int payBill();
	}

	 

	class OnlineCustomer extends Customer {
	    public int payBill() {
	        return 1000;
	    }

	 

	    public float claimCashBack() {
	        return super.billAmount * 0.05f;
	    }
	}

	 

	class PolymorphismDemo {
	    public static void main(String[] args) {

	 

	        OnlineCustomer onlineCustomer = new OnlineCustomer();
	        PolymorphismDemo demo = new PolymorphismDemo();
	        demo.doUserThings(onlineCustomer);
	    }

	 

	    public void doUserThings(Customer customer) {
	        if (customer instanceof OnlineCustomer) {
	            OnlineCustomer onlineCustomer = (OnlineCustomer) customer;
	            float cashBackAmount = onlineCustomer.claimCashBack();
	            System.out.println("Claimed cash back: " + cashBackAmount);
	        } else {
	            System.out.println("Cash back not applicable for this customer.");
	        }
	    } 
}
